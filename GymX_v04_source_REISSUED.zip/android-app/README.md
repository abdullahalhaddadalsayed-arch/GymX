# GymX — your personal gym companion

**Project status:** functional mobile prototype and Android APK build source. **This archive is not an APK**; compilation has not been performed on a Samsung device.

GymX is a local-first, English-language fitness journal designed specifically for one Android user. Interface: charcoal/black with lime accents. No accounts, ads, social features, rest timers or heart-rate tracking.

## What's working in the prototype

- Five mobile tabs: Home, Plan, Scan, Library, Progress.
- Manual workout dates and times; optional weekly repeat; ordered exercises with target sets/reps.
- Editable goal templates for full-body, push, pull, legs and cardio.
- Searchable starter catalog of **85 exercises** by muscle and equipment.
- Interactive front/back anatomical muscle selector.
- Exercises with illustrated placeholder pose, basic safety/technique pointers and YouTube tutorial search links.
- Start and save workouts: weight (kg), reps and completed sets; prefill prior weights and show last performance when opening an exercise.
- Cardio: duration (minutes), distance (km), speed (km/h), calories (kcal), **no heart rate**.
- Actual persistent historical workout log, seven-day summary and monthly totals.
- Day-versus-lifted-weight SVG chart with muscle, exercise/machine and date-range filters. The chart shows the highest completed set weight per workout day.
- Weekly private progress photos for front, side and back, with prior-week comparison. They are stored using IndexedDB.
- Camera/photo picker for machine scanning; fallback manual equipment selection.
- Export/import complete JSON backup including photos. The Android shell implements native backup export to a selected folder.
- Optional secure online AI recognition gateway implemented in `gateway/` (not deployed and not preconfigured).

### Not yet complete

- **Installable APK binary:** Not produced here because Android SDK/Gradle dependencies are unavailable. The Android Studio project is included to build it.
- **AI machine recognition:** Requires a separately deployed gateway and provider credentials. The gateway source code is included; never put an AI provider secret in the APK.
- **Exercise imagery/videos:** The in-app pose art is schematic, not a precise animation for each exercise. Links open a video search in your browser; licensed curated video integration is still pending.
- **Exercises dataset integration:** A hand-curated 85-item starter library is included. The external 1,324-item dataset has *not* been imported. Its media has licensing restrictions.
- Device build/installation, Android camera routing, and long-term photo durability have **not** been verified on a physical Samsung phone.

## Quick preview on a computer or phone

Open `GymX_Prototype.html` in a browser. It is standalone and needs no external styles/scripts. Files opened directly using `file://` may have different storage behavior depending on browser security settings. For persistent local browser operation and offline PWA support, serve `web/` over localhost or a private HTTPS host. In an Android APK, the bundled site is served from Android's reserved secure asset domain by `WebViewAssetLoader`, enabling local browser storage.

To serve `web/` locally:

```
cd web
python -m http.server 8080
```

Then open `http://localhost:8080` on the same computer. Do not expose this server publicly; it is a personal prototype.

## Build GymX APK (Android Studio)

1. Extract `GymX_Android_Source.zip` on a computer with Android Studio and Android SDK installed.
2. Open the **android-app** folder in Android Studio. Allow Gradle (8.10.2 compatible), Android Gradle Plugin, SDK 35 and dependencies to download.
3. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**, or run `gradle :app:assembleDebug` if Gradle is installed.
4. Find `android-app/app/build/outputs/apk/debug/app-debug.apk`.
5. Transfer to your Samsung Galaxy S26 Ultra and install it by allowing installation from that file manager source if Android prompts. Keep the debug APK private.
6. The app has no account. Start with a workout and open **Settings > Export backup** regularly.

**Alternative**: Add the extracted Android project to a private GitHub repository. The supplied `.github/workflows/build-apk.yml` builds a debug APK through GitHub Actions, available in the workflow's artifacts. This uses the repository's source files and requires explicit user action to create/push the repository.

Android shell details:
- Kotlin `Activity` hosting a trusted `WebViewAssetLoader` origin, not a Jetpack Compose UI. This is a **hybrid Android prototype**, an intentional compromise to deliver the functionality now.
- Android system photo picker/camera intent with `FileProvider` for `input type=file`.
- Room/SQLite database is *not* used; workout state is in localStorage, photos in IndexedDB. Can be migrated to Room when a full native version is needed.
- Native SAF save dialog for JSON backup download.
- WebView file access disabled and other remote navigation blocked; tutorial links may need browser dispatch depending on WebView target-window behavior.

## Real AI setup

`gateway/` contains an optional Cloudflare Worker that uses a server-held `OPENAI_API_KEY`, a separate long random `GYMX_ACCESS_TOKEN` and a vision-capable model. See `gateway/README.md` to deploy and connect it in GymX Settings. Photos are sent only after clicking Identify with AI. AI recognition may be wrong; compare to manufacturer labels and verify the correct machine before use.

## Reference repository licensing

- https://github.com/hasaneyldrm/exercises-dataset — exercise text/data under MIT, but **media is NOT covered by that license** and is attributed to Gym visual under distinct terms. This prototype has not copied its media.
- https://github.com/DuarteSantos8/openGym — AGPL-3.0; consulted as feature inspiration. No openGym code/media has been copied.
- GymX prototype source (`web/`, Android shell, worker) is original to this deliverable.

## Privacy and data loss

All training information stays on your phone in the local prototype unless you manually export it. Progress photos are compressed before being stored in IndexedDB. They are never sent to the AI endpoint; only selected machine photos are sent if you opt in. Local data can be deleted by uninstalling, clearing browser/site data, or using Reset; export a backup regularly. Consider encrypted storage if you plan to retain highly sensitive personal photos.

## Testing

Static JS syntax checking and a scripted Chromium interaction test of planning, exercise selection, completed-set logging, history and chart updates passed. Android compilation and physical camera verification have not been performed.
