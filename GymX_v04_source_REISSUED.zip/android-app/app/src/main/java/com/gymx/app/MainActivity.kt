package com.gymx.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import org.json.JSONObject
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.io.OutputStreamWriter
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import java.io.File

/** Single-user GymX Android shell. The UI and offline logic live in assets. */
class MainActivity : Activity() {
    companion object { private const val PICK_IMAGE = 4813; private const val SAVE_BACKUP = 4814; private const val APP_URL = "https://appassets.androidplatform.net/assets/index.html" }
    private lateinit var webView: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var cameraUri: Uri? = null
    private var backupContents: String? = null
    private lateinit var matcher: OfflineMachineMatcher

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(9,13,17)
        window.navigationBarColor = android.graphics.Color.rgb(17,24,30)
        matcher = OfflineMachineMatcher(this) { operation, response ->
            runOnUiThread {
                if (::webView.isInitialized) webView.evaluateJavascript(
                    "window.gymxMLResult && window.gymxMLResult(${JSONObject.quote(operation)},${response})", null)
            }
        }
        webView = WebView(this)
        setContentView(webView)
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            @Suppress("DEPRECATION")
            allowFileAccessFromFileURLs = false
            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs = false
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                return request?.url?.let { assetLoader.shouldInterceptRequest(it) }
            }
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                if (uri.host == "appassets.androidplatform.net") return false
                // External exercise-video search opens in the phone's browser, not in the app's trusted local origin.
                if (uri.scheme == "https" && (uri.host == "www.youtube.com" || uri.host == "youtube.com")) {
                    try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) { }
                    return true
                }
                // Reject all other navigations: the trusted WebView also exposes a local backup bridge.
                return true
            }
        }
        webView.addJavascriptInterface(object {
            @JavascriptInterface fun listReferences() { matcher.list() }
            @JavascriptInterface fun matchPhoto(image: String) { matcher.match(image) }
            @JavascriptInterface fun addReference(image: String, exerciseId: String, name: String) {
                matcher.add(image, exerciseId, name)
            }
            @JavascriptInterface fun removeReference(id: String) { matcher.remove(id) }

            @JavascriptInterface
            fun saveBackup(json: String) {
                if (json.length > 60_000_000) return
                runOnUiThread {
                    backupContents = json
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/json"
                        putExtra(Intent.EXTRA_TITLE, "GymX_Backup_${System.currentTimeMillis()}.json")
                    }
                    startActivityForResult(intent, SAVE_BACKUP)
                }
            }
        }, "GymXNative")
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return openFilePicker(params)
            }
        }
        webView.loadUrl(APP_URL)
    }

    private fun openFilePicker(params: WebChromeClient.FileChooserParams?): Boolean {
        val accept = params?.acceptTypes?.firstOrNull { it.isNotEmpty() } ?: "image/*"
        val pick = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = if (accept.contains("json")) "application/json" else "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        var camera: Intent? = null
        cameraUri = null
        if (!accept.contains("json")) {
            try {
                val folder = File(cacheDir, "captures").apply { mkdirs() }
                val photo = File(folder, "gymx_${System.currentTimeMillis()}.jpg")
                cameraUri = FileProvider.getUriForFile(this, "$packageName.fileprovider", photo)
                camera = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                    putExtra(MediaStore.EXTRA_OUTPUT, cameraUri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                }
            } catch (_: Exception) { camera = null }
        }
        return try {
            val chooser = Intent.createChooser(pick, "Choose or take a photo")
            camera?.let { chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(it)) }
            startActivityForResult(chooser, PICK_IMAGE)
            true
        } catch (_: Exception) {
            fileCallback?.onReceiveValue(null)
            fileCallback = null
            false
        }
    }

    @Deprecated("Deprecated Android Activity result API is used to keep shell dependencies small")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == SAVE_BACKUP) {
            val target = if (resultCode == RESULT_OK) data?.data else null
            val content = backupContents
            if (target != null && content != null) {
                try {
                    contentResolver.openOutputStream(target)?.use { stream ->
                        OutputStreamWriter(stream, Charsets.UTF_8).use { it.write(content) }
                    }
                    Toast.makeText(this, "GymX backup saved", Toast.LENGTH_SHORT).show()
                } catch (ex: Exception) { Toast.makeText(this, "Backup save failed", Toast.LENGTH_LONG).show() }
            }
            backupContents = null
            return
        }
        if (requestCode != PICK_IMAGE) return
        val uri = if (resultCode == RESULT_OK) data?.data ?: cameraUri else null
        fileCallback?.onReceiveValue(uri?.let { arrayOf(it) })
        fileCallback = null
        cameraUri = null
    }

    @Deprecated("Android back navigation override")
    override fun onBackPressed() {
        // SPA exposes a consistent back action: close the sheet or return Home.
        webView.evaluateJavascript("window.gymxBack ? window.gymxBack() : false") { result ->
            if (result == "false") super.onBackPressed()
        }
    }

    override fun onDestroy() {
        fileCallback?.onReceiveValue(null)
        matcher.close()
        webView.destroy()
        super.onDestroy()
    }
}
