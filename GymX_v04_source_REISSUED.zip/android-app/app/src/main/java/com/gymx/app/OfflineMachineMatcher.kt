package com.gymx.app

import android.content.Context
import android.graphics.BitmapFactory
import android.util.Base64
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.imageembedder.ImageEmbedder
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.concurrent.Executors
import kotlin.math.sqrt

/** Private offline machine-image retrieval using a pretrained MobileNetV3 image embedder. */
internal class OfflineMachineMatcher(private val context: Context, private val reply: (String, JSONObject) -> Unit) {
    private val queue = Executors.newSingleThreadExecutor()
    private val dir = File(context.filesDir, "machine_references").apply { mkdirs() }
    private val index = File(dir, "index.json")
    private var model: ImageEmbedder? = null
    private fun action(name: String, block: () -> JSONObject) {
        queue.execute {
            val result = try { block() } catch (e: Exception) {
                JSONObject().put("ok", false).put("error", e.message ?: "Unable to process image")
            }
            reply(name, result)
        }
    }
    private fun data(): JSONArray = try { JSONArray(index.readText()) } catch (_: Exception) { JSONArray() }
    private fun persist(a: JSONArray) {
        val file = File(dir, "index.tmp")
        file.writeText(a.toString())
        if (!file.renameTo(index)) { index.writeText(a.toString()); file.delete() }
    }
    private fun embedding(image: String): FloatArray {
        if (image.length > 8_000_000 || !image.startsWith("data:image/"))
            throw IllegalArgumentException("Image must be under 6 MB")
        val bytes = Base64.decode(image.substringAfter(','), Base64.DEFAULT)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IllegalArgumentException("Invalid image")
        var sample = 1
        while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size,
            BitmapFactory.Options().apply { inSampleSize = sample })
            ?: throw IllegalArgumentException("Image could not be decoded")
        try {
            if (model == null) {
                val opts = ImageEmbedder.ImageEmbedderOptions.builder()
                    .setBaseOptions(BaseOptions.builder().setModelAssetPath("mobilenet_v3_small.tflite").build())
                    .build()
                model = ImageEmbedder.createFromOptions(context, opts)
            }
            val raw = model!!.embed(BitmapImageBuilder(bmp).build())
                .embeddingResult().embeddings().first().floatEmbedding()
            val norm = sqrt(raw.sumOf { it.toDouble() * it.toDouble() }).toFloat()
            if (norm == 0f) throw IllegalArgumentException("Image has no usable features")
            return FloatArray(raw.size) { raw[it] / norm }
        } finally { bmp.recycle() }
    }
    fun list() = action("list") {
        val out = JSONArray()
        val entries = data()
        for (i in 0 until entries.length()) {
            val e = entries.getJSONObject(i)
            out.put(JSONObject().put("id", e.getString("id"))
                .put("exerciseId", e.getString("exerciseId")).put("name", e.getString("name")))
        }
        JSONObject().put("ok", true).put("references", out)
    }
    fun add(image: String, exerciseId: String, name: String) = action("add") {
        if (!Regex("^[a-zA-Z0-9_-]{1,48}$").matches(exerciseId) || name.length !in 2..100)
            throw IllegalArgumentException("Choose a valid exercise")
        val refs = data()
        if (refs.length() >= 150) throw IllegalArgumentException("150-photo reference limit reached")
        val vec = embedding(image)
        val numbers = JSONArray()
        vec.forEach { numbers.put(it.toDouble()) }
        val key = UUID.randomUUID().toString()
        // Keep the reference photo privately for later re-indexing; it is never uploaded.
        File(dir, "$key.jpg").writeBytes(Base64.decode(image.substringAfter(','), Base64.DEFAULT))
        refs.put(JSONObject().put("id", key).put("exerciseId", exerciseId)
            .put("name", name).put("vector", numbers))
        persist(refs)
        JSONObject().put("ok", true).put("count", refs.length())
    }
    fun match(image: String) = action("match") {
        val refs = data()
        if (refs.length() == 0) JSONObject().put("ok", true).put("needReferences", true)
        else {
            val probe = embedding(image)
            val best = linkedMapOf<String, Pair<JSONObject, Double>>()
            for (i in 0 until refs.length()) {
                val entry = refs.getJSONObject(i)
                val vec = entry.getJSONArray("vector")
                if (vec.length() != probe.size) continue
                var sim = 0.0
                for (j in probe.indices) sim += probe[j] * vec.getDouble(j)
                val id = entry.getString("exerciseId")
                if (sim > (best[id]?.second ?: -100.0)) best[id] = entry to sim
            }
            val output = JSONArray()
            best.values.sortedByDescending { it.second }.take(5).forEach { (entry, score) ->
                output.put(JSONObject().put("exerciseId", entry.getString("exerciseId"))
                    .put("name", entry.getString("name")).put("similarity", score))
            }
            JSONObject().put("ok", true).put("results", output).put("referenceCount", refs.length())
        }
    }
    fun remove(id: String) = action("remove") {
        val refs = data()
        val keep = JSONArray()
        var deleted = false
        for (i in 0 until refs.length()) {
            val entry = refs.getJSONObject(i)
            if (entry.getString("id") == id) deleted = true else keep.put(entry)
        }
        if (!deleted) throw IllegalArgumentException("Reference not found")
        persist(keep)
        File(dir, "$id.jpg").delete()
        JSONObject().put("ok", true).put("count", keep.length())
    }
    fun close() { queue.execute { model?.close() }; queue.shutdown() }
}
