# GymX v0.4 — Free Exercise DB integration

This Android source builds with GitHub Actions without software installed on the laptop.

The ZIP contains GymX v0.3 as a base and two importer scripts. The full exercise data, JPG demonstration media, and model are fetched **at build time** from public sources. They are not included in this compact source ZIP.

## Build flow

1. Upload `GymX_FreeDB_Source_v04.zip` to the root of the existing private GymX GitHub repository.
2. Run the `Build GymX Free Exercise DB APK` GitHub Actions workflow.
3. The job downloads github.com/yuhonas/free-exercise-db at main.
4. The importer merges non-stretching exercises, upgrades exact-name matches, preserves all GymX exercise IDs, copies compatible JPEG image references into APK assets, and builds debug APK.
5. The step-by-step tutorial and the images are displayed offline on the exercise detail screen.

## What is new

- Up to 753 strength/weightlifting/cardio/plyometric records are eligible from 876 upstream exercises; the total is 161 plus eligible records not matched by normalized name.
- Two JPG demonstration images per exercise where available, stored locally.
- Detailed instructions, equipment, primary/secondary muscles, difficulty and training style.
- Existing history and core GymX exercise IDs are kept.
- Existing machine reference matching stays unchanged (not a pretrained 16-class classifier).

## Legal/provenance

The upstream repo has an Unlicense public-domain declaration. Photographs may derive from original material of uncertain provenance. Use for personal evaluation and confirm rights before redistribution or commercialization. Upstream link: https://github.com/yuhonas/free-exercise-db.

## Verification

The importer has been syntax-checked and run with a synthetic dataset; the actual Android APK must be built and tested on your Samsung Galaxy S26 Ultra.

## Backup reminder

Before installing an APK built with a different signing key, export your GymX workout data. An app reinstall can erase local workout data and the offline machine references are not part of the workout-backup export.
