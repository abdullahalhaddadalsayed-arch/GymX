"""Patch GymX WebView exercise UI to show two locally stored photos and detailed instructions."""
import sys
from pathlib import Path
root=Path(sys.argv[1])
p=root/'app/src/main/assets/app.js'
s=p.read_text(encoding='utf-8')
find='function exercisePoster(ex){'
assert s.count(find)==1
replace='''function exercisePoster(ex){if(ex.imagesLocal&&ex.imagesLocal.length){return `<div class="poster freedb-poster"><div class="freedb-photos">${ex.imagesLocal.map((src,i)=>`<img src="${ehtml(src)}" alt="${ehtml(ex.name)} demonstration ${i+1}" loading="lazy" decoding="async">`).join('')}</div><span class="poster-title">${ehtml(ex.muscle.toUpperCase())} · ${ehtml(ex.equipment.toUpperCase())}</span></div>`;}'''
s=s.replace(find,replace,1)
needle="${section('How to perform')}<p class=\"p\">${ehtml(ex.steps)}</p>"
assert s.count(needle)==1
replacement="${section('How to perform')}${ex.instructions&&ex.instructions.length?`<ol class=\"freedb-steps\">${ex.instructions.map(step=>`<li>${ehtml(step)}</li>`).join('')}</ol>`:`<p class=\"p\">${ehtml(ex.steps)}</p>`}"
s=s.replace(needle,replacement,1)
# Add details to search index
needle="${(e.airtable?.minorMuscles||[]).join(' ')}"
assert s.count(needle)==1
s=s.replace(needle,needle+" ${((e.primaryMuscles||[]).concat(e.secondaryMuscles||[])).join(' ')} ${e.level||''}")
p.write_text(s,encoding='utf-8')
css=root/'app/src/main/assets/style.css'
with css.open('a',encoding='utf-8') as f:
    f.write('''\n/* GymX free-exercise-db photo guides */\n.freedb-poster{height:auto;min-height:unset;padding:14px;display:flex;flex-direction:column;gap:12px}\n.freedb-photos{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;width:100%}\n.freedb-photos img{width:100%;height:190px;object-fit:contain;border:1px solid rgba(255,255,255,.06);border-radius:12px;background:#111819}\n.freedb-photos img:only-child{grid-column:span 2}\n.freedb-steps{padding-left:24px;margin:10px 0 20px;color:#d2dcda;line-height:1.65}\n.freedb-steps li{margin-bottom:12px;padding-left:3px}\n''')
print('Patched exercise modal and guide search.')
