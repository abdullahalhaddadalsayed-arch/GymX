#!/usr/bin/env python3
"""GymX: merge free-exercise-db into original local catalog and bundle images.
Run in GitHub Actions after extracting GymX v0.4 source and free-exercise-db archive.
Keeps stable GymX IDs and leaves logged workout records untouched.
"""
import argparse
import hashlib
import json
import re
import shutil
import unicodedata
from pathlib import Path
from urllib.parse import quote

ALLOWED = {"strength", "powerlifting", "olympic weightlifting", "strongman", "cardio", "plyometrics"}
MUSCLES = {
    "abdominals":"Core", "abductors":"Legs", "adductors":"Legs", "biceps":"Arms",
    "calves":"Legs", "chest":"Chest", "forearms":"Arms", "glutes":"Legs",
    "hamstrings":"Legs", "lats":"Back", "lower back":"Back", "middle back":"Back",
    "neck":"Shoulders", "quadriceps":"Legs", "shoulders":"Shoulders",
    "traps":"Back", "triceps":"Arms"
}
EQUIPMENT = {
    "medicine ball":"Medicine Ball", "dumbbell":"Dumbbell", "body only":"Bodyweight",
    "bands":"Resistance Band", "kettlebells":"Kettlebell", "foam roll":"Foam Roller",
    "cable":"Cable", "machine":"Machine", "barbell":"Barbell", "exercise ball":"Exercise Ball",
    "e-z curl bar":"EZ-Bar", "other":"Other"
}

def normalized(name):
    txt = unicodedata.normalize('NFKD', name).encode('ascii','ignore').decode().lower()
    return re.sub(r'[^a-z0-9]+','',txt)

def embed_image_files(rows, src, out):
    wanted = set()
    for row in rows:
        for image in row.get('images',[])[:2]:
            if isinstance(image,str) and image.endswith('.jpg') and '..' not in Path(image).parts:
                wanted.add(image)
    copied = 0
    for p in sorted(wanted):
        source = src/'exercises'/p
        if not source.is_file():continue
        target=out/'freedb-images'/p
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(source,target)
        copied+=1
    return copied

def main(root,upstream,dry_run=False):
    root=Path(root)
    upstream=Path(upstream)
    assets=root/'app/src/main/assets'
    exercises_file=assets/'exercises.js'
    original=exercises_file.read_text(encoding='utf-8')
    start=original.find('['); end=original.rfind(']')
    if start<0 or end<start: raise ValueError('GymX exercise.js not found')
    existing=json.loads(original[start:end+1])
    records=json.loads((upstream/'dist/exercises.json').read_text(encoding='utf-8'))
    if len(records)<800: raise ValueError('Unexpectedly small free-exercise-db dataset')
    by_name={normalized(row['name']):row for row in existing}
    used_ids={row['id'] for row in existing}
    seen_source=set()
    overlap=0;added=0;image_misses=0
    eligible=[r for r in records if r.get('category') in ALLOWED]
    for row in eligible:
        name=row.get('name','').strip()
        if not name: continue
        key=normalized(name)
        if key in seen_source:continue
        seen_source.add(key)
        primary=row.get('primaryMuscles') or []
        group = 'Cardio' if row['category'] in ('cardio','plyometrics') else MUSCLES.get(primary[0] if primary else '', 'Core')
        instruction_list=[s.strip() for s in (row.get('instructions') or []) if isinstance(s,str) and s.strip()]
        images=[]
        for filename in (row.get('images') or [])[:2]:
            if isinstance(filename,str) and '..' not in Path(filename).parts:
                original_image=upstream/'exercises'/filename
                if original_image.is_file():
                    images.append('freedb-images/'+quote(filename,safe='/'))
                else:image_misses+=1
        eq=EQUIPMENT.get(row.get('equipment'), 'Other')
        meta={
            'source':'yuhonas/free-exercise-db',
            'sourceId':row['id'],
            'category':row.get('category'),
            'level':row.get('level'),
            'force':row.get('force'),
            'mechanic':row.get('mechanic'),
            'primaryMuscles':primary,
            'secondaryMuscles':row.get('secondaryMuscles') or [],
            'instructions':instruction_list,
            'imagesLocal':images
        }
        if key in by_name:
            # IMPORTANT: Keep existing stable IDs, chosen muscle/equipment and workout history.
            target=by_name[key]
            target.update(meta)
            if instruction_list:target['steps']=' '.join(instruction_list)
            overlap+=1
        else:
            uid='fedb_'+hashlib.sha1(row['id'].encode()).hexdigest()[:16]
            if uid in used_ids:raise ValueError('ID collision: '+uid)
            used_ids.add(uid)
            ent={
                'id':uid,'name':name,'muscle':group,'equipment':eq,
                'movement':row.get('force') or 'general',
                'kind':'cardio' if row.get('category') in ('cardio','plyometrics') else 'strength',
                'steps':' '.join(instruction_list) or 'Consult a qualified instructor or the equipment manufacturer.',
                'mistakes':'Use controlled technique; do not exceed your comfortable movement range.'
            }
            ent.update(meta)
            existing.append(ent)
            by_name[key]=ent
            added+=1
    if not dry_run:
        exercises_file.write_text('const EXERCISES = '+json.dumps(existing,ensure_ascii=False,separators=(',',':'))+';\n',encoding='utf-8')
        copied=embed_image_files(eligible,upstream,assets)
    else:copied=0
    metrics={'upstream_count':len(records),'eligible_count':len(eligible),'base_count':len(existing)-added,'overlapping_names':overlap,'new_exercises':added,'result_count':len(existing),'bundled_photos':copied,'missing_photo_references':image_misses,'category_counts':{c:sum(1 for r in eligible if r.get('category')==c) for c in sorted(ALLOWED)}}
    if not dry_run:
        (root/'import-results.json').write_text(json.dumps(metrics,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(metrics,indent=2));return metrics

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--android-app',default='android-app');p.add_argument('--free-db',required=True);p.add_argument('--dry-run',action='store_true')
    args=p.parse_args();main(args.android_app,args.free_db,args.dry_run)
