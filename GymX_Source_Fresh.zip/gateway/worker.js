/**
 * GymX optional AI recognition gateway — Cloudflare Workers.
 * Secrets (NEVER put these in GymX's bundled JavaScript):
 *  OPENAI_API_KEY: provider credential
 *  GYMX_ACCESS_TOKEN: a long random secret you configure in GymX Settings
 * No database, logging or image storage is implemented in this worker.
 */
const cors={
  'Access-Control-Allow-Origin':'*',
  'Access-Control-Allow-Methods':'POST, OPTIONS',
  'Access-Control-Allow-Headers':'Content-Type, X-GymX-Access',
  'Cache-Control':'no-store',
  'Content-Type':'application/json; charset=utf-8'
};
const reply=(status,body)=>new Response(JSON.stringify(body),{status,headers:cors});
function equalSecret(a,b){if(!a||!b||a.length!==b.length)return false;let diff=0;for(let i=0;i<a.length;i++)diff|=a.charCodeAt(i)^b.charCodeAt(i);return diff===0}
export default {
  async fetch(req,env){
    if(req.method==='OPTIONS')return new Response(null,{status:204,headers:cors});
    if(req.method!=='POST')return reply(405,{error:'Use POST'});
    if(!env.GYMX_ACCESS_TOKEN||!env.OPENAI_API_KEY)return reply(503,{error:'Gateway secrets are not configured'});
    if(!equalSecret(req.headers.get('X-GymX-Access')||'',env.GYMX_ACCESS_TOKEN))return reply(401,{error:'Invalid token'});
    if(Number(req.headers.get('Content-Length')||0)>8_000_000)return reply(413,{error:'Image too large'});
    let body;try{body=await req.json()}catch{return reply(400,{error:'Invalid JSON'})}
    if(typeof body.image_base64!=='string'||!/^data:image\/(jpeg|png|webp);base64,/.test(body.image_base64)||body.image_base64.length>8_000_000)return reply(400,{error:'Expected JPEG/PNG/WebP data URL under 8 MB'});
    const candidates=Array.isArray(body.candidate_exercises)?body.candidate_exercises.filter(x=>typeof x==='string'&&x.length<100).slice(0,130):[];
    const instructions=`You identify commercial gym equipment from user-supplied photos. The equipment may be partly obscured. Only discuss visible gym equipment, not any people. If image insufficient, be explicit about uncertainty. Return ONLY JSON: {"name":"likely general machine type or unknown","reason":"one brief caution about the visible evidence and uncertainty","matches":["Exercise name from candidates",...]}. Pick at most 4 matches, copying exactly from this candidate list where plausible: ${JSON.stringify(candidates)}. Never invent manufacturer adjustments or safety settings; recommend checking labels and manual. If unclear, return an empty matches array.`;
    try{
      const r=await fetch('https://api.openai.com/v1/chat/completions',{
        method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${env.OPENAI_API_KEY}`},
        body:JSON.stringify({model:env.OPENAI_VISION_MODEL||'gpt-4.1-mini',temperature:0.2,max_tokens:350,response_format:{type:'json_object'},messages:[{role:'system',content:instructions},{role:'user',content:[{type:'text',text:'Identify the gym machine in this photograph and return plausible matching exercise names from the supplied catalog.'},{type:'image_url',image_url:{url:body.image_base64,detail:'low'}}]}]})
      });
      if(!r.ok)return reply(502,{error:'AI provider request failed',status:r.status});
      const json=await r.json();const obj=JSON.parse(json.choices?.[0]?.message?.content||'{}');
      const allowed=new Set(candidates);
      const matches=Array.isArray(obj.matches)?obj.matches.filter(x=>allowed.has(x)).slice(0,4):[];
      return reply(200,{name:typeof obj.name==='string'?obj.name.slice(0,100):'Unknown machine',reason:typeof obj.reason==='string'?obj.reason.slice(0,280):'',matches});
    }catch{return reply(502,{error:'Recognition temporarily unavailable'})}
  }
};
