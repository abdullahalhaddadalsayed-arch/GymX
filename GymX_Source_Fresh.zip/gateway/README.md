# GymX optional AI recognition gateway

This is **server-side integration code**, not a running AI service. Real recognition is disabled until you deploy it.

1. Create a Cloudflare Workers account and install Wrangler on your own computer (`npm install -g wrangler`).
2. In this `gateway/` directory, authenticate using `wrangler login`.
3. Add provider credentials as a secret: `wrangler secret put OPENAI_API_KEY`.
4. Generate a long random access token (`openssl rand -hex 32`), then `wrangler secret put GYMX_ACCESS_TOKEN`.
5. Run `wrangler deploy` and copy your HTTPS worker URL.
6. Open GymX → Settings and paste the HTTPS URL and the *GymX access token* (never the provider API key).
7. Scan a machine photo, press **Identify with AI**, confirm a suggested machine or choose **Manual**.

The worker uses a vision-capable model via the OpenAI API. API usage may incur charges and needs internet. This optional backend does not store submitted images. Protect your Workers endpoint with its long access token; Cloudflare or API-provider operational logging and retention may still apply under their policies. You can remove the URL from Settings to disable online submissions.

For personal prototype use only. Before any public release, add stronger user authentication, quotas/rate limits, abuse prevention, updated provider checks and security review.
